module model {
    exports geometry;
    requires javafx.fxml;
    requires javafx.controls;
}