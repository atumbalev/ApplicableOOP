package com;

import java.net.URL;
import java.util.ResourceBundle;

import digital.DateViewController;
import javafx.fxml.FXML;

public class DateViewTestController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private DateViewController pnlUserComponent;


    @FXML
    void initialize() {

    }
}
