module validator {
    exports validator to loginGUI;
}