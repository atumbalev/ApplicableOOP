package Coin;

public enum Face {
    HEAD,
    TAIL
}
