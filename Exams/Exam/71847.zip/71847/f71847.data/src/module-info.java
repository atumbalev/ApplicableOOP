module f71847.data {
    exports f71847.data;
}