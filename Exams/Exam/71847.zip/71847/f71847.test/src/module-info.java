module f71847.test {
    requires f71847.data;
}