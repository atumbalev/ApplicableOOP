module model {
    exports model to gui;
}