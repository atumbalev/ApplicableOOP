package f71847.test1.game;

public interface Countable {
    String count(Card[] hand);
}
