module f71847.test1.game {
    exports f71847.test1.game;
}